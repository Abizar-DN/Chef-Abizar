package com.example.chefabizar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DaftarMasakan (
    var ingredients : String = "",
    var cook : String = "",
    var photo : Int = 0
)