package com.example.chefabizar

object FoodsData {
    private val foodNames = arrayOf ("Ayam Goreng",
        "Ayam Panggang Bumbu Merah",
        "Mie Goreng",
        "Nasi Goreng",
        "Rawon",
        "Rendang",
        "Sambal Petai Udang",
        "Sate Ayam Madura",
        "Sop Buntut",
        "Soto Ayam",
        "Tahu dan Tempe Bacem" )

    private val foodDetails = arrayOf("Ayam goreng ungkep gaya tradisional ini diolah dengan dua teknik. Diungkep atau dimasak dengan sedikit air dan bumbu hingga matang. Kemudian digoreng dalam minyak banyak dan panas hingga garing.\n" +
         "Bumbu ungkep bisa dipakai bumbu kuning dengan tambahan kunyit atau bumbu putih tanpa kunyit dengan tambahan gula aren. Bumbu komplet yang meresap ke dalam daging ayam ini membuat rasanya lezat.\n",
        "Resep Ayam Bakar Bumbu Merah adalah salah satu menu sehari hari yang sederhana murah dan hemat tapi enak. Hidangkan menu sajian rumahan yang sederhana ini, untuk keluarga tercinta di rumah.",
        "Mi goreng, salah satu masakan kaki lima yang menggugah selera. Jika kebetulan sedang punya waktu, kamu bisa membuat mi goreng jawa sendiri di rumah. Menu simpel ini bisa kamu hidangkan untuk makan malam keluarga. Untuk pelengkapnya, mi goreng jawa dapat dimasak dengan aneka sayuran dan suwiran ayam.",
         "Nasi goreng jadi sarapan praktis dan favorit orang Indonesia. Resep Nasi Goreng Bumbu Iris ini bisa dicoba untuk sarapan yang mengenyangkan. Sisa Nasi Goreng Bumbu Iris juga bisa jadi bekal makanan di kantor. Bisa juga menjadi pilihan bekal sarapan enak untuk anak.",
        "Hidangan sup daging berkuah hitam yang menjadi ikon kuliner Jawa Timur ini disebut dengan rawon. Warna hitam pada kuah rawon berasal dari bumbu khas Indonesia bernama kluwak. Penambahan bumbu kluwek tak hanya memberi warna hita, melainkan juga rasa legit pada kuah rawon.", "Berasal dari kata 'marandang' yaitu proses memasak untuk menghilangkan air. Untuk itu, proses masak rendang asli Minang atau Padang ini membutuhkan waktu sekitar 7-8 jam hingga daging menjadi kering, minyak naik dan tak ada lagi kandungan air.",
        "Kalau kamu sedang mencari inspirasi sambal sekaligus lauk yang tahan lama, sambal goreng udang petai bisa jadi jawabannya. Goreng sambal sampai kering agar awet. Sambal goreng udang petai bisa jadi lauk pelengkap nasi kuning maupun nasi gurih.",
        "Sate madura terkenal nikmat karena bumbunya meresap sampai ke daging. Tak sampai di sana, masih ada sambal atau bumbu kacang yang menjadi pelengkap makan sate. Kamu bisa membuat sate madura dari Sajian Sedap ini untuk sajian bakar-bakaran tahun baru. Gunakan paha ayam fillet agar daging lebih empuk dan bumbu mudah meresap.",
        "Sop buntut bisa dibilang comfort food orang Indonesia. Betapa nikmat menyantap sup hangat penuh rempah dengan daging buntut yang empuk.  Saking banyak penggemar, sop buntut juga dijual di banyak hotel Indonesia.",
        "Soto ayam punya beberapa versi, tergantung asal daerah. Salah satu versi soto ayam yang terkenal adalah soto ayam ambengan khas Surabaya. Soto ambengan tidak menggunakan santan pada kuahnya. Namun, kuah soto ayam ini terkenal agak kental dan pekat. Lantaran bumbu soto ayam ambengan memang terkenal royal.",
        "Tempe dan tahu, bahan makanan yang mudah diolah tanpa ribet seperti menjadi bacem. Bacem atau baceman adalah cara masak dari Yogyakarta. Bahan makanan umumnya tempe, tahu, telor, dan atau ayam direndam dalam air gula supaya lebih awet.")

    private val foodingredients = arrayOf ("<li>  Bahan : </li>\n" +
            "-\t<li>  1 ekor ayam negeri/jantan</li>\n" +
            "-\t<li>  3 sdm minyak sayur</li>\n" +
            "-\t<li>  500 ml air kelapa/air</li>\n" +
            "-\t<li>  2 lembar daun salam</li>\n" +
            "-\t<li>  2 lembar daun jeruk</li>\n" +
            "-\t<li>  3 cm lengkuas, memarkan</li>\n" +
            "-\t<li>  Bumbu: <li>\n" +
            "-\t<li>  8 butir bawang merah</li>\n" +
            "-\t<li>  4 siung bawang putih</li>\n" +
            "-\t<li>  4 butir kemiri</li>\n" +
            "-\t<li>  1/2 sdt merica butiran</li>\n" +
            "-\t<li>  1 cm jahe</li>\n" +
            "-\t<li>  3 cm kunyit tua</li>\n" +
            "-\t<li>  20 g gula merah</li>\n" +
            "-\t<li>  2 sdt garam</li>\n", "<li>Bahan utama : </li>\n" +
            "-\t<li>  1 ekor ayam, potong potong</li>\n" +
            "-\t<li>  1 sendok teh air jeruk limau</li>\n" +
            "-\t<li>  1 sendok teh garam</li>\n" +
            "-\t<li>  Minyak untuk menumis</li>\n" +
            "-\t<li>  2 lembar daun salam</li>\n" +
            "-\t<li>  1/2 sendok makan garam</li>\n" +
            "-\t<li>  2 cm lengkuas, memarkan</li>\n" +
            "-\t<li>  1/2 sendok teh merica bubuk</li>\n" +
            "-\t<li>  600 ml santan dari 1 butir kelapa</li>\n" +
            "-\t<li>  1 sendok makan gula merah</li>\n" +
            "\n" +
            "<li>  Bumbu halus : </li>\n" +
            "-\t<li>  8 butir bawang merah</li>\n" +
            "-\t<li>  4 siung bawang putih </li>\n" +
            "-\t<li>  4 butir kemiri, sangrai</li>\n" +
            "-\t<li>  8 buah cabai merah keriting, bakar</li>\n" +
            "-\t<li>  4 buah cabai merah besar, bakar</li>\n" +
            "-\t<li>  1 sendok teh terasi, bakar</li>\n", "<li>  Bahan : </li>\n" +
            "-\t<li>  120g mie telur, rebus lalu sisihkan</li>\n" +
            "-\t<li>  100g taoge, siram air panas dan tiriskan</li>\n" +
            "-\t<li>  200g sawi, iris kasar lalu seduh dan tiriskan</li>\n" +
            "-\t<li>  2butir telur ayam kampung, kocok lepas<li>\n" +
            "-\t<li>  2siung bawang putih, iris tipis</li>\n" +
            "-\t<li>  4butir bawang merah, iris tipis</li>\n" +
            "-\t<li>  2buah cabai rawit, iris tipis</li>\n" +
            "-\t<li>  1sdt garam</li>\n" +
            "-\t<li>  ½sdt merica putih bubuk</li>\n" +
            "-\t<li>  ½sdt gula pasir</li>\n" +
            "-\t<li>  30ml Bango Kecap Manis</li>\n" +
            "-\t<li>  2sdm minyak sayur</li>\n" +
            "\n" +
            "<li>  Pelengkap : </li>\n" +
            "-\t<li>  timun besar, iris melintang</li>\n" +
            "-\t<li>  bawang merah goring</li>\n" +
            "-\t<li>  cabai rawit</li>\n", "<li>  Bahan : </li>\n" +
            "-\t<li>  2 sdm minyak sayur</li>\n" +
            "-\t<li>  2 butir bawang merah, iris tipis</li>\n" +
            "-\t<li>  2 siung bawang putih, iris tipis</li>\n" +
            "-\t<li>  150 g babat rebus, iris tipis panjang</li>\n" +
            "-\t<li>  400 g nasi putih</li>\n" +
            "-\t<li>  1 batang daun bawang, iris kasar</li>\n" +
            "-\t<li>  4 sdm kecap manis</li>\n" +
            "-\t<li>  Haluskan: </li>\n" +
            "-\t<li>  2 buah cabai merah besar, buang bijinya, rebus</li>\n" +
            "-\t<li>  2 buah cabai rawit merah</li>\n" +
            "-\t<li>  2 butir bawang merah</li>\n" +
            "-\t<li>  1 siung bawang putih</li>\n" +
            "-\t<li>  1/2 sdt terasi goreng</li>\n" +
            "-\t<li>  1 sdt garam</li>\n" +
            "-\t<li>  Pelengkap: </li>\n" +
            "-\t<li>  2 sdm bawang merah goreng</li>\n" +
            "-\t<li>  Acar timun. </li>\n", "<li>Bahan : </li>\n" +
            "-\t<li>500g daging sandung lamur sapi</li>\n" +
            "-\t<li>1dengkul sapi, belah dua</li>\n" +
            "-\t<li>3lembar daun jeruk purut segar</li>\n" +
            "-\t<li>1batang serai, memarkan</li>\n" +
            "-\t<li>1sdm air asam jawa</li>\n" +
            "-\t<li>2batang daun bawang, iris seukuran 1 cm</li>\n" +
            "-\t<li>1sdm Royco Kaldu Sapi</li>\n" +
            "-\t<li>1sdm garam</li>\n" +
            "-\t<li>3liter air</li>\n" +
            "-\t<li>5sdm minyak goreng</li>\n" +
            "\n" +
            "<li>Bumbu halus : </li>\n" +
            "-\t<li>4 siung bawang putih</li>\n" +
            "-\t<li>8 butir bawang merah</li>\n" +
            "-\t<li>5 buah keluak, geprek dan rendam isinya dengan air panas</li>\n" +
            "-\t<li>4 butir kemiri, sangria</li>\n" +
            "-\t<li>1 cm kunyit, bakar</li>\n" +
            "\n" +
            "<li>Pelengkap : </li>\n" +
            "-\t<li>Taoge pendek</li>\n" +
            "-\t<li>Telur asin</li>\n" +
            "-\t<li>Sambal rawit</li>\n" +
            "-\t<li>Jeruk nipis</li>\n" +
            "-\t<li>Emping</li>\n", "<li>Bahan : </li>\n" +
            "-\t<li>1 kilogram daging sapi yang telah dipotong-potong</li>\n" +
            "-\t<li>1,5 liter santan kental</li>\n" +
            "-\t<li>1 lembar daun kunyit </li>\n" +
            "-\t<li>100 gram cabai merah halus </li>\n" +
            "-\t<li>100 gram bawang merah yang telah dihaluskan</li> \n" +
            "-\t<li>5 lembar daun jeruk</li>\n" +
            "-\t<li>1 batang serai yang dimemarkan </li>\n" +
            "-\t<li>4 siung bawang putih yang telah dihaluskan </li>\n" +
            "-\t<li>1 potong jahe yang dimemarkan</li>\n" +
            "-\t<li>1 potong lengkuas yang dimemarkan</li> \n" +
            "-\t<li>50 mililiter kecap manis Garam</li> \n", "<li>  Bahan-bahan untuk rendaman udang : </li>\n" +
            "-\t<li>  250 gram udang</li>\n" +
            "-\t<li>  1/4 sendok teh garam</li>\n" +
            "-\t<li>  1 sendok makan air jeruk nipis</li>\n" +
            "\n" +
            "<li>  Bahan-bahan sambal udang petai: </li>\n" +
            "-\t<li>  2 papan petai</li>\n" +
            "-\t<li>  50 gram cabai merah keriting</li>\n" +
            "-\t<li>  25 gram cabai rawit</li>\n" +
            "-\t<li>  50 gram bawang merah</li>\n" +
            "-\t<li>  25 gram bawang putih</li>\n" +
            "-\t<li>  150 gram tomat dipotong-potong</li>\n" +
            "-\t<li>  1/2 sendok teh garam</li>\n" +
            "-\t<li>  1/2 sendok makan gula</li>\n" +
            "-\t<li>  1/2 sendok makan kecap manis</li>\n" +
            "-\t<li>  2 lembar daun jeruk</li>\n" +
            "-\t<li>  Minyak goreng secukupnya. </li>\n", "<li>Bahan : </li>\n" +
            "-\t<li> Daging ayam fillet, potong dadu 400 gram</li>\n" +
            "-\t<li> Jeruk nipis ½ buah\n" +
            "-\t<li> Bawang putih yang sudah dihaluskan 3 siung</li>\n" +
            "-\t<li> Merica bubuk ½ sdt</li>\n" +
            "-\t<li> Kacang tanah yang sudah digoreng dan ditumbuk halus 150 gram</li>\n" +
            "-\t<li> Daun jeruk yang sudah disobek-sobek 3 lembar</li>\n" +
            "-\t<li> Kecap manis 3 sdm</li>\n" +
            "-\t<li> Gula merah yang diserut halus 1 sdm</li>\n" +
            "-\t<li> Garam 1sdt</li>\n" +
            "-\t<li> Gula pasir 1 sdt</li>\n" +
            "-\t<li> Air 500 ml</li>\n" +
            "-\t<li> Minyak 2 sdm</li>\n" +
            "-\t<li> Cabai merah keriting 4 buah</li>\n" +
            "-\t<li> Bawang merah 6 butir</li>\n" +
            "-\t<li> Bawang putih 3 siung</li>\n" +
            "-\t<li> Kemiri yang sudah disangrai 3 butir</li>\n" +
            "-\t<li> Margarin 2 sdm</li>\n" +
            "-\t<li> Cabai rawit</li>\n" +
            "-\t<li> Lontong</li>\n", "<li>  Bahan : </li>\n" +
            "-\t<li>  1½ kg buntut sapi </li>\n" +
            "-\t<li>  12 siung bawang putih </li>\n" +
            "-\t<li>  1½ sdm merica putih utuh </li>\n" +
            "-\t<li>  5 iris pala </li>\n" +
            "-\t<li>  7-8biji cengkeh </li>\n" +
            "-\t<li>  8 siung bawang merah Rajang</li>\n" +
            "-\t<li>  8 siung bawang putih rajang </li>\n" +
            "-\t<li>  2 - 3 tangkai seledri </li>\n" +
            "-\t<li>  3 - 4 tangkai daun bawang </li>\n" +
            "-\t<li>  3 buah tomat belah 4 </li>\n" +
            "-\t<li>  3/4 sdt gula pasir </li>\n" +
            "-\t<li>  Kentang yang sudah dikupas, dipotong dadu, dan direbus </li>\n" +
            "-\t<li>  Wortel yang sudah dikupas, diiris, dan direbus</li>\n", "<li>Bahan : </li>\n" +
            "-\t<li>  1/2 ekor ayam negeri, potong-potong</li>\n" +
            "-\t<li>  3 sdm minyak sayur</li>\n" +
            "-\t<li>  2 batang serai, memarkan</li>\n" +
            "-\t<li>  3 lembar daun jeruk</li>\n" +
            "-\t<li>  2 lembar daun salam</li>\n" +
            "-\t<li>  1 sdm kaldu ayam bubuk</li>\n" +
            "-\t<li>  1 sdt gula pasir</li>\n" +
            "-\t<li>  Bumbu Halus: </li>\n" +
            "-\t<li>  7 butir bawang merah</li>\n" +
            "-\t<li>  5 siung bawang putih</li>\n" +
            "-\t<li>  2 butir kemiri</li>\n" +
            "-\t<li>  3 cm kunyit</li>\n" +
            "-\t<li>  1 cm jahe</li>\n" +
            "-\t<li>  2 sdt garam</li>\n" +
            "-\t<li>  Isian: </li>\n" +
            "-\t<li>  200 g tauge, siram air panas, tiriskan</li>\n" +
            "-\t<li>  100 g suun kering, rendam air panas hingga lunak</li>\n" +
            "-\t<li>  2 butir telur rebus, kupas, potong-potong</li>\n" +
            "-\t<li>  Pelengkap: </li>\n" +
            "-\t<li>  bawang merah goreng</li>\n" +
            "-\t<li>  seledri cincang</li>\n" +
            "-\t<li>  sambal rawit</li>\n" +
            "-\t<li>  jeruk nipis</li>\n" +
            "-\t<li>  kecap manis</li>\n" +
            "-\t<li>  koya</li>\n", "<li> Bahan : </li>\n" +
            "-\t<li>  3 papan tempe, potong setebal 2 cm</li>\n" +
            "-\t<li>  750 ml air kelapa</li>\n" +
            "-\t<li>   2 sdm gula merah</li>\n" +
            "-\t<li>   1 batang serai, memarkan</li>\n" +
            "-\t<li>   2 lembar daun salam</li>\n" +
            "-\t<li>   1 sdt garam</li>\n" +
            "-\t<li>   5 sdm Bango Kecap Manis</li>\n" +
            "-\t<li>   2 cm lengkuas, memarkan</li>\n" +
            "-\t<li>   2 sdm minyak, untuk menumis</li>\n" +
            "-\t<li>   250 ml minyak, untuk menggoreng</li>\n" +
            "<li> Bumbu halus: </li>\n" +
            "-\t<li>   6 butir bawang merah</li>\n" +
            "-\t<li>   4 siung bawang putih</li>\n" +
            "-\t<li>   1 sdt biji ketumbar, sangria</li>\n")

    private val foodcook = arrayOf ("<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Potong-potong ayam menjadi 8 bagian. Cuci bersih lalu tiriskan hingga tidak berair. </li>\n" +
            "-\t<li>  Bumbu: Giling semua bahan bumbu hingga halus benar. </li>\n" +
            "-\t<li>  Panaskan minyak, tumis bumbu halus hingga wangi. </li>\n" +
            "-\t<li>  Tambahkan daun salam, daun jeruk, lengkuas dan serai, aduk rata. </li>\n" +
            "-\t<li>  Masukkan potongan ayam, aduk hingga kaku. </li>\n" +
            "-\t<li>  Tuangi air kelapa, tutup wajan. Masak dengan api sedang hingga bumbu meresap dan ayam empuk. Angkat dan dinginkan. </li>\n" +
            "-\t<li>  Panaskan minyak banyak dalam wajan di atas api sedang. </li>\n" +
            "-\t<li>  Goreng ayam hingga kering kecokelatan. Angkat dan tiriskan. </li>\n" +
            "-\t<li>  Sajikan ayam dengan sambal goreng atau sambal dadak dan lalapan. </li>\n", "<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Ayam yang telah di potong potong, lumuri dengan air jeruk nipis dan garam hingga rata, setelah itu diamkan ayam selama 15 menit, lalu bakar ayam hingga kecoklatan, angkat. <li>\n" +
            "-\t<li>  Panaskan sedikit minyak, lalu tumis bumbu yang dihaluskan, daun salam, dan lengkuas, tumis hingga bumbu matang. </li>\n" +
            "-\t<li>  Tambahkan dengan santan, merica bubuk, garam dan gula merah, aduk hingga rata. Masukkan ayam lalu aduk hingga mendidih. </li>\n" +
            "-\t<li>  Setelah kuah mendidih, kecilkan api lalu masak dengan api kecil hingga bumbu meresap dan kuah menyusut. Angkat ayam. </li>\n" +
            "-\t<li>  Bakar ayam sambil di oles dengan sisa bumbu hingga kecoklatan. </li>\n", "<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Tumis irisan bawang merah, putih dan cabai hingga harum. </li>\n" +
            "-\t<li>  Tambahkan kocokan telur lepas dan aduk rata di atas wajan. </li>\n" +
            "-\t<li>  Masukan mie, taoge, dan sawi yang telah direbus dan ditiriskan sebelumnya. Kembali aduk perlahan. </li>\n" +
            "-\t<li>  Tambahkan gula, garam, merica dan Bango Kecap Manis  secukupnya. </li>\n" +
            "-\t<li>  Setelah matang dan tercampur rata, angkat dan sajikan dengan pelengkap. </li>\n", "<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Tumis bawang merah dan bawang putih hingga layu. </li>\n" +
            "-\t<li>  Masukkan Bumbu Halus, aduk hingga matang dan harum. </li>\n" +
            "-\t<li>  Tambahkan babat, aduk hingga rata. </li>\n" +
            "-\t<li>  Masukkan nasi, daun bawang dan kecap manis. </li>\n" +
            "-\t<li>  Aduk hingga rata dan agak kering. </li>\n" +
            "-\t<li>  Angkat, Sajikan hangat dengan Pelengkapnya. </li>\n", "<li>Cara Memasak : </li>\n" +
            "-\t<li>Rebus daging dan dengkul sapi hingga setengah lunak. Potong daging sesuai selera. </li>\n" +
            "-\t<li>Masukkan Royco Kaldu Sapi dan garam ke dalam air rebusan daging. </li>\n" +
            "-\t<li>Tumis bumbu halus, lengkuas, daun jeruk, dan serai hingga harum dan matang. </li>\n" +
            "-\t<li>Masukkan potongan daging ke dalam tumisan, masak hingga bumbu meresap. </li>\n" +
            "-\t<li>Masukkan tumisan daging ke dalam kuah kaldu. Masak dengan api kecil hingga daging empuk. </li>\n" +
            "-\t<li>Sajikan hangat beserta pelengkap. </li>\n", "<li>Cara memasak : </li>\n" +
            "-\t<li>Rebuslah santan hingga mendidih, </li>\n" +
            "-\t<li>lalu masukkan semua bumbu dan daging sapi. </li>\n" +
            "-\t<li>Masak sampai air menyusut, </li>\n" +
            "-\t <li>lalu kecilkan api, dan aduk-aduk sampai keluar minyak. </li> \n" +
            "-\t<li>Sajikan Rendang selagi hangat. </li>\n", "<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Kupas kulit udang dan letakkan dagingnya di dalam satu wadah. </li>\n" +
            "-\t<li>  Masukkan garam dan perasan air jeruk nipis. Aduk hingga tercampur rata, lalu diamkan beberapa saat. </li>\n" +
            "-\t<li>  Blender cabai keriting, cabai rawit, bawang merah, bawang putih, dan tomat sampai halus. </li>\n" +
            "-\t<li>  Panaskan minyak di atas penggorengan dengan api sedang, goreng udang hingga matang, lalu tiriskan. </li>\n" +
            "-\t<li>  Goreng petai dalam minyak panas, kemudian tiriskan. </li>\n" +
            "-\t<li>  Tumis bumbu yang telah dihaluskan dalam minyak panas. </li>\n" +
            "-\t<li>  Tambahkan garam, gula, daun jeruk, dan kecap manis dalam tumisan. Aduk hingga tercampur rata. </li>\n" +
            "-\t<li>  Masukkan udang dan petai yang telah digoreng. Aduk semuanya sampai merata. </li>\n" +
            "-\t<li>  Matikan kompor dan sambal udang petaimu siap disajikan di meja makan. </li>\n", "<li> Cara memasak : </li>\n" +
            "-\t<li> Pertama-tama, siapkan bahan-bahan untuk perendam ayam yang akan digunakan untuk resep Sate Ayam Madura yakni jeruk nipis, bawang putih, dan merica bubuk. Peras jeruk nipis dan ambil airnya, haluskan bawang putih, dan masukkan merica bubuk agar menjadi bahan perendam ayam. </li>\n" +
            "-\t<li> Kedua, lumuri bahan perendam ayam tersebut ke potongan daging ayam yang telah dipotong dadu untuk resep Sate Ayam Madura. Setelah itu, masukkan dan simpan ke dalam kulkas terlebih dahulu. </li>\n" +
            "-\t<li> Ketiga, siapkan bahan-bahan untuk bumbu halus resep Sate Ayam Madura yakni cabai merah keriting, bawang merah, bawang putih, dan kemiri yang sudah disangrai. Haluskan semuanya menjadi bumbu halus resep Sate Ayam Madura dengan cara diulek/diblender. </li>\n" +
            "-\t<li> Jangan lupa siapkan bahan-bahan untuk bumbu kacang resep Sate Ayam Madura yakni  kacang tanah goreng yang sudah digoreng dan ditumbuk halus, daun jeruk yang sudah disobek-sobek, kecap manis, gula merah serut, garam, dan gula pasir. Masukkan semuanya dan tumis bersama dengan bumbu halus resep Sate Ayam Madura. </li>\n" +
            "-\t<li> Setelah itu, tuangkan air dan masak bumbu kacang resep Sate Ayam Madura hingga mengental dan mengeluarkan minyak. Angkat dan sisihkan. </li>\n" +
            "-\t<li> Kemudian, keluarkan ayam yang akan dibuat untuk resep Sate Ayam Madura dari dalam kulkas dan susun/tusuk ke tusukan sate. </li>\n" +
            "-\t<li> Berikutnya, siapkan alat untuk membakar Sate Ayam Madura seperti pemanggang/pan/wajan datar anti lengket. </li>\n" +
            "-\t<li> Selanjutnya, campurkan bumbu kacang, kecap manis, dan margarin sebagai bahan olesan untuk resep Sate Ayam Madura. </li>\n" +
            "-\t<li> Lalu, oleskan bahan dan bumbu olesan tersebut ke potongan Sate Ayam Madura secara merata. </li>\n" +
            "-\t<li> Bakar sate ayam madura sambil dibolak-balik. Jangan lupa juga untuk olesi Sate Ayam Madura dengan bumbu agar semakin meresap. Ayam harus sering dibolak-balik agar kematangan sate ayam madura lebih merata. </li>\n" +
            "-\t<li> Akhirnya selesai sudah resep Sate Ayam Madura dan siap disajikan bersama siraman bumbu kacang untuk Lebaran nanti! Jangan lupa siapkan bahan pelengkap untuk resep Sate Ayam Madura seperti irisan bawang merah, cabai rawit, kecap manis, dan lontong ya biar makin lezat!. </li>\n", "<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Langkah pertama untuk membuat sop buntut adalah didihkan air lalu masukkan buntut sapi, rebus hingga setengah mendidih, kemudian angkat dan tiriskan. </li>\n" +
            "-\t<li>  Setelah setengah direbus baru cuci dan bersihkan buntut sapi dengan air dingin mengalir. Setelah dicuci bersih, tambahkan air dingin secukupnya untuk merebus buntut sapi dengan api kecil. Rebus sampai mendidih kembali. </li>\n" +
            "-\t<li>  Sembari menunggu, kamu bisa haluskan bawang putih bersama merica, setelah halus dilanjutkan dengan menumis dengan minyak secukupnya. (Jika warna bumbu sudah agak cokelat muda, tuangkan dua gelas air lalu didihkan hingga mendidih. Kemudian tuang dengan disaring ke dalam kuah buntut yang sudah mendidih. Langkah ini bisa disesuaikan dengan selera, jika ingin tidak disaring tidak masalah ). </li>\n", "<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Langkah pertama untuk membuat sop buntut adalah didihkan air lalu masukkan buntut sapi, rebus hingga setengah mendidih, kemudian angkat dan tiriskan. </li>\n" +
            "-\t<li>  Setelah setengah direbus baru cuci dan bersihkan buntut sapi dengan air dingin mengalir. Setelah dicuci bersih, tambahkan air dingin secukupnya untuk merebus buntut sapi dengan api kecil. Rebus sampai mendidih kembali. </li>\n" +
            "-\t<li>  Sembari menunggu, kamu bisa haluskan bawang putih bersama merica, setelah halus dilanjutkan dengan menumis dengan minyak secukupnya. (Jika warna bumbu sudah agak cokelat muda, tuangkan dua gelas air lalu didihkan hingga mendidih. Kemudian tuang dengan disaring ke dalam kuah buntut yang sudah mendidih. Langkah ini bisa disesuaikan dengan selera, jika ingin tidak disaring tidak masalah ). </li>\n" +
            "-\t<li>  Tambahkan irisan pala, cengkeh dan daun bawang serta seledri yang sudah disimpulkan. ( Sebaiknya seledri dimasukkan utuh dan tidak diiris tipis-tipis. Lalu tambahkan garam dan penyedap. Angkat seledri yang sudah layu, buang dan rebus buntut sapi sampai empuk ). <li>\n" +
            "-\t<li>  Agar menambah aroma, kamu bisa goreng bawang merah bawang putih yang sudah diiris tipis, goreng hingga kecokelatan.  ( Remas-remas dan taburkan ke dalam kaldu dan tambahkan gula pasir. Jangan lupa untuk merasakan sop buntut dan menambah bumbu sesuai seleramu jika perlu ). </li>\n" +
            "-\t<li>  Jika sudah hidangkan sop buntut dengan irisan tomat, kentang , wortel dan daun bawang. Nikmati sop buntut selagi hangat. </li>\n", "<li>  Cara Memasak : </li>\n" +
            "-\t<li>  Didihkan air secukupnya dalam panci, masukkan potongan ayam. Masak dengan api kecil.\n" +
            "-\t<li>  Sementara itu tumis Bumbu Halus hingga harum dan matang. </li>\n" +
            "-\t<li>  Tambahkan daun salam, daun jeruk, serai, kaldu bubuk dan gula. Aduk hingga rata. </li>\n" +
            "-\t<li>  Angkat, masukkan ke dalam rebusan ayam, masak terus hingga daging ayam empuk. </li>\n" +
            "-\t<li>  Angkat daging ayam lalu suwir kasar dagingnya dan sisihkan. </li>\n" +
            "-\t<li>  Penyajian: Susun suun, tauge, ayam suwir dan telur dalam mangkuk. </li>\n" +
            "-\t<li>  Siram dengan kaldu panasnya. </li>\n" +
            "-\t<li>  Sajikan dengan Pelengkapnya</li>\n", "<li> Cara Memasak : <li>\n" +
            "-\t<li>   Panaskan minyak, tumis bumbu halus, daun salam, lengkuas, serai hingga harum. <li>\n" +
            "-\t<li>   Masukkan tempe dan air kelapa, aduk rata. <li>\n" +
            "-\t<li>   Tuangkan Bango Kecap manis, gula merah, dan garam. Masak dengan api kecil hingga bumbu meresap dan air menyusut. <li> \n" +
            "-\t<li>   Setelah matang, angkat dan sisihkan. <li>\n" +
            "-\t<li>   Panaskan minyak, goreng tempe hingga berwarna lebih kecokelatan. <li>\n")

    private val foodsImage = intArrayOf(R.drawable.ayam_goreng,
        R.drawable.ayam_panggang_bumbu_merah,
        R.drawable.mie_goreng,
        R.drawable.nasi_goreng,
        R.drawable.rawon,
        R.drawable.rendang,
        R.drawable.sambal_petai_udang,
        R.drawable.sate_ayam_madura,
        R.drawable.sop_buntut,
        R.drawable.soto_ayam,
        R.drawable.tahu_dan_tempe_bacem)

    val listData: ArrayList<Food>
    get() {
        val list = arrayListOf<Food>()
        for (position in foodNames.indices){
            val food = Food ()
            food.name = foodNames[position]
            food.detail = foodDetails[position]
            food.photo = foodsImage[position]
            list.add(food)
        }
        return list
    }
}